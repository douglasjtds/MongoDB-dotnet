﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Alura.GoogleMaps.Web.Models
{
    public class conectandoMongoDBGeo
    {
        //XXX TRABALHE AQUI
        // Crie a classe de conexão com o MongoDB


    }
}