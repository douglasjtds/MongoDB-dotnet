﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace Alura.GoogleMaps.Web.Models
{
    public class Aeroporto
    {
        //XXX TRABALHE AQUI
        // Crie a classe que representa um aeroporto no MongoDB

    }
}